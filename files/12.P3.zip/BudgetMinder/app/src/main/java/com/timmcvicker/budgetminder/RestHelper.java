package com.timmcvicker.budgetminder;

import android.content.Context;
import android.location.Location;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.SyncFailedException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class RestHelper {
    private static RestHelper sInstance;

    public Exception getCurrentException() {
        return currentException;
    }

    public void setCurrentException(Exception currentException) {
        this.currentException = currentException;
    }

    private Exception currentException;

    //used to return the id in create bc the api is stupid
    private Integer integerToReturn;

    public static synchronized RestHelper getInstance() {
        if (sInstance == null) {
            sInstance = new RestHelper();
        }
        return sInstance;
    }

    public RestHelper() {
        currentException = null;
    }

    //URLS
    private static final String URL_LOGIN = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/get_user.php";
    private static final String URL_CREATE_USER = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/create_user.php";
    private static final String URL_UPDATE_USER = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/update_user.php";
    private static final String URL_GET_TRANSACTIONS = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/get_transactions_for_user.php";
    private static final String URL_GET_USERS = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/get_all_users.php";
    private static final String URL_CREATE_TRANSACTION = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/create_transaction.php";
    private static final String URL_GET_VENUES = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/get_venues.php";
    private static final String URL_CREATE_VENUE = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/create_venue.php";

    public void loginUser(final String usernameInput, final String password, final Context activityContext) {
        currentException = null;
        new AsyncTask<Void,String,String>(){
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_LOGIN);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "uname=" + usernameInput;

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null)
                    {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    currentException = e;
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results){
                UserManager userManager = UserManager.getInstance();
                try {

                    if(!results.contains("No")){
                        JSONObject json = new JSONObject(results);

                        //this is successful, check pass
                        String passwordFromDB = json.getString("password");
                        if (passwordFromDB.equals(password)) {
                            //login successful
                            userManager.setUsername(json.getString("username"));
                            userManager.setUser_name(json.getString("name"));
                            userManager.setUser_id(json.getInt("id"));
                            userManager.setUser_balance(json.getDouble("balance"));
                            userManager.setLoginError(null);
                            Log.i("Login", "Logging in user: " + userManager.getUsername());
                        } else {
                            //login failed; incorrect password
                            userManager.setLoginError("Incorrect password");
                            Log.e("Login", "Incorrect password");
                        }
                    }
                    else{
                        //login failed-user doesn't exist
                        userManager.setLoginError("User does not exist");
                        Log.e("Login", "User " + usernameInput + " does not exist");
                    }
                } catch (JSONException e) {
                    //login failed-internal error
                    currentException = e;
                    userManager.setLoginError("Internal Error");
                    Log.e("Login", "Internal error " + e.getMessage());
                }
                LoginActivity.finishLogin(activityContext);
            }
        }.execute();
    }

    public void createUser(final String name, final String username, final String password, final Double balance, final Context activityContext) {
        currentException = null;
        integerToReturn = null;
        new AsyncTask<Void,String,String>(){
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_CREATE_USER);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "name=" + name + "&uname=" + username + "&balance=" + balance + "&pword=" + password;

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null)
                    {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results){
                try {
                    if(results.contains("user id created:")) {
                        Log.i("Register", "User " + username + " created.");

                        integerToReturn = Integer.parseInt(results.split(": ")[1].split("<")[0]);
                    }
                    else {
                        currentException = new RegisterException(username);
                        Log.e("Register", "Unable to create user " + username);
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("Register", "Internal error " + e.getMessage());
                }
                ManageAccountActivity.finishRegister(username, integerToReturn, activityContext);
            }
        }.execute();
    }

    public void updateUser(final int id, final String name, final String username, final String password, final Double balance) {
        currentException = null;
        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_UPDATE_USER);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "name=" + name + "&uname=" + username + "&balance=" + balance + "&pword=" + password + "&id=" + id;

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    if (results.contains("user id updated:")) {
                        Log.i("User Update", "User " + username + " updated.");
                        UserManager userManager = UserManager.getInstance();
                        userManager.setLoginError(null);
                        userManager.setUser_balance(balance);
                        userManager.setUser_id(id);
                        userManager.setUser_name(name);
                        userManager.setUsername(username);
                    } else {
                        currentException = new RegisterException(username);
                        Log.e("User Update", "Unable to update user " + username);
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("User Update", "Internal error " + e.getMessage());
                }
            }
        }.execute();
    }

    public void getExternalUsers(final Context context) {
        currentException = null;
        final Map<Integer, String> mapToReturn = new HashMap<>();
        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_GET_USERS);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "";

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    if (results.contains("No users found")) {
                        currentException = new SyncFailedException("Unable to sync users");
                        Log.e("User Sync", "Unable to sync users ");
                    } else {
                        JSONArray jsonArray = new JSONArray(results);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            mapToReturn.put(json.getInt("id"), json.getString("username"));
                        }
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("User Sync", "Internal error " + e.getMessage());
                }
                BudgetDatabaseHelper.finishSyncUsers(mapToReturn, context);
            }
        }.execute();
    }

    public void getAllTransactionsForUser(final Context context) {
        final UserManager userManager = UserManager.getInstance();
        final Integer userId = userManager.getUser_id();
        currentException = null;

        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_GET_TRANSACTIONS);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "";

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    if (results.contains("No transactions")) {
                        Log.e("Get Transactions", "There are no transactions for " + userId);
                    } else {
                        JSONArray jsonArray = new JSONArray(results);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);

                            Transaction transaction = new Transaction();
                            transaction.setId(json.getInt("id"));
                            transaction.setDescription(json.getString("description"));
                            transaction.setAmount(json.getDouble("amount"));
                            transaction.setDate(json.getString("date"));
                            transaction.setRecurring(json.getString("recurring_ind"));
                            transaction.setRecurringInDays(json.getInt("recurring_in_days"));
                            transaction.setExpense(json.getString("expense_ind"));
                            transaction.setUserId(json.getInt("user_id"));
                            transaction.setLocationId(json.getInt("location_id"));

                            userManager.addTransaction(transaction);
                        }
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("Get Transactions", "Internal error " + e.getMessage());
                    e.printStackTrace();
                }
                BudgetDatabaseHelper.syncTransactions(context);
            }
        }.execute();
    }

    public void createTransaction(final Context context, final Transaction transaction) {
        currentException = null;

        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_CREATE_TRANSACTION);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);
                    String isExpense;
                    if (transaction.isExpense()) isExpense = "1";
                    else isExpense = "0";

                    String parameters = "desc=" + transaction.getDescription() + "&amount=" + transaction.getAmount() + "&expense="
                            + isExpense + "&location=" + transaction.getLocationId() + "&user=" + UserManager.getInstance().getUser_id()
                            + "&date=" + getDateTime(transaction.getDate());

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    if (results.contains("created")) {
                        Log.i("Create Transactions", "Transaction created!");
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("Create Transactions", "Internal error " + e.getMessage());
                    e.printStackTrace();
                }
                RestHelper.getInstance().getAllTransactionsForUser(context);
                EnterTransactionActivity.finishCreate(context, transaction);
            }
        }.execute();
    }

    private String getDateTime(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return dateFormat.format(date);
    }

    public void updateUserBalance(final Double balance) {
        currentException = null;
        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_UPDATE_USER);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "balance=" + balance + "&id=" + UserManager.getInstance().getUser_id();

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    UserManager userManager = UserManager.getInstance();

                    if (results.contains("user id updated:")) {
                        Log.i("Balance Update", "User " + userManager.getUsername() + " updated.");
                    } else {
                        currentException = new RegisterException(userManager.getUsername());
                        Log.e("Balance Update", "Unable to update user " + userManager.getUsername());
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("Balance Update", "Internal error " + e.getMessage());
                }
            }
        }.execute();
    }

    public void createVenue(final Context context, final Venue venue) {
        currentException = null;

        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_CREATE_VENUE);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "name=" + venue.getName() + "&latitude=" + venue.getLocation().getLatitude() + "&longitude=" + venue.getLocation().getLongitude() +
                            "&type=" + venue.getType().name();

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    if (results.contains("created")) {
                        Log.i("Create Venue", "Venue created!");
                        String substring = results.substring(results.indexOf(": ")+2, results.indexOf("<"));
                        venue.setId(Integer.parseInt(substring));
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("Create Venue", "Internal error " + e.getMessage());
                    e.printStackTrace();
                }
                RestHelper.getInstance().getAllVenues(context);
                EnterTransactionActivity.finishCreate(venue, context);
            }
        }.execute();
    }

    public void getAllVenues(final Context context) {
        currentException = null;

        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_GET_VENUES);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "";

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    if (results.contains("No venues")) {
                        Log.e("Get Venues", "There are no venues");
                    } else {
                        VenueManager venueManager = VenueManager.getInstance();
                        JSONArray jsonArray = new JSONArray(results);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);

                            Venue venue = new Venue();
                            venue.setId(json.getInt("id"));

                            Double lat = json.getDouble("latitude");
                            Double lon = json.getDouble("longitude");
                            Location location = new Location("");
                            location.setLatitude(lat);
                            location.setLongitude(lon);
                            venue.setLocation(location);

                            venue.setName(json.getString("name"));
                            venue.setType(VenueType.valueOf(json.getString("type")));


                            venueManager.addVenue(venue);
                        }
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("Get Venues", "Internal error " + e.getMessage());
                    Log.e("Get Venues", results);
                    e.printStackTrace();
                }
                BudgetDatabaseHelper.syncVenues(context);
            }
        }.execute();
    }
}

