package com.timmcvicker.budgetminder;

import android.location.Location;

import java.util.HashMap;
import java.util.Map;

public class VenueManager {
    private static VenueManager sInstance;

    private Map<Location, Venue> venueMap;

    public static synchronized VenueManager getInstance() {
        if (sInstance == null) {
            sInstance = new VenueManager();
        }
        return sInstance;
    }

    private VenueManager() {
        venueMap = new HashMap<>();
    }

    public void clear() {
        sInstance = new VenueManager();
    }

    public Map<Location, Venue> getVenueMap() {
        return venueMap;
    }

    public void addVenue(Venue venue) {
        Location location = venue.getLocation();
        venueMap.put(location, venue);
    }

    public Venue getVenueIfExists(Location location) {
        Location key = venueIsInMap(location);
        if(key != null) {
            return venueMap.get(key);
        }
        return null;
    }

    private Location venueIsInMap(Location location) {
        for (Location curr:
             venueMap.keySet()) {
            if (Math.abs(curr.getLongitude()-location.getLongitude()) < 0.0009 && Math.abs(curr.getLatitude()- location.getLatitude()) < 0.0009)
                return curr;
        }
        return null;
    }

    public Venue getById(Integer id) {
        for (Venue venue :
                venueMap.values()) {
            if (venue.getId() == id) return venue;
        }
        return null;
    }
}
