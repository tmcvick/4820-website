package com.timmcvicker.budgetminder;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EnterTransactionActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    private String type;
    private static Transaction transaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_transaction);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("Expense");
        categories.add("Income");


        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        type = parent.getSelectedItem().toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    public void createTransaction(View view) {
        TextView descInput = (TextView) findViewById(R.id.descInput);
        TextView amountInput = (TextView) findViewById(R.id.amountInput);
        DatePicker datePicker = (DatePicker) findViewById(R.id.datePicker2);
        Date dueDate = new Date();

        dueDate.setYear(datePicker.getYear()-1900);
        dueDate.setMonth(datePicker.getMonth());
        dueDate.setDate(datePicker.getDayOfMonth());

        transaction = new Transaction();
        transaction.setDescription(descInput.getText().toString());
        transaction.setAmount(Double.parseDouble(amountInput.getText().toString()));
        transaction.setDate(dueDate);

        transaction.setRecurring("0");
        transaction.setRecurringInDays(0);

        String tranType;
        if(type.equals("Expense")) tranType = "1";
        else tranType = "0";

        transaction.setExpense(tranType);

        handleLocation();
    }

    public static void finishCreate(Venue venue, Context context) {
        transaction.setLocationId(venue.getId());
        RestHelper.getInstance().createTransaction(context, transaction);
    }

    public static void finishCreate(Context context, Transaction transaction) {
        UserManager userManager = UserManager.getInstance();
        Double balance = userManager.getUser_balance();
        if (transaction.isExpense()){
            balance = balance - transaction.getAmount();
        } else {
            balance = balance + transaction.getAmount();
        }

        RestHelper.getInstance().updateUserBalance(balance);
        BudgetDatabaseHelper.getInstance(context).syncUsers(context);
        userManager.setUser_balance(balance);

        Intent intentToLogin = new Intent(context, HomeActivity.class);
        context.startActivity(intentToLogin);
    }

    private void handleLocation() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String message = ("Would you like to create a new location or search for one?");
        builder.setMessage(message);
        builder.setPositiveButton("Create New", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                startActivity(new Intent(getApplicationContext(), NewLocationActivity.class));
            }
        });
        builder.setNegativeButton("Search", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                startActivity(new Intent(getApplicationContext(), ListLocationActivity.class));

            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
