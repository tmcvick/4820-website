package com.timmcvicker.budgetminder;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.Arrays;
import java.util.List;


public class NewLocationActivity extends AppCompatActivity implements LocationListener, AdapterView.OnItemSelectedListener{
    private LocationManager locationManager;
    private String locationType;
    private Location userLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_new);

        Spinner spinner = (Spinner) findViewById(R.id.spinner2);
        // Spinner Drop down elements
        List<VenueType> categories = Arrays.asList(VenueType.values());


        // Creating adapter for spinner
        ArrayAdapter<VenueType> dataAdapter = new ArrayAdapter<VenueType>(this, android.R.layout.simple_spinner_dropdown_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(this);

        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            //do same stuff
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,  this );
            } catch ( SecurityException e ) { e.printStackTrace(); }

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //do stuff
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                try {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,  this );
                } catch ( SecurityException e ) { e.printStackTrace(); }

            }
        }
    }

    private void requestLocation() {
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            //do same stuff
            try {
                userLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            } catch ( SecurityException e ) { e.printStackTrace(); }

        }
        Log.e("Location Request", userLocation.toString());

    }

    private void handleLocation() {
        VenueManager venueManager = VenueManager.getInstance();
        Location newLocation = new Location("");
        newLocation.setLongitude(userLocation.getLongitude());
        newLocation.setLatitude(userLocation.getLatitude());
        final Venue venue = venueManager.getVenueIfExists(newLocation);
        final Context context = this.getApplicationContext();
        if (venue != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            String message = String.format("This location already exists! Name: %s, Type: %s", venue.getName(), venue.getType());
            builder.setMessage(message);
            builder.setPositiveButton("Use this location", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    EnterTransactionActivity.finishCreate(venue, context);
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            Venue newVenue = new Venue();
            newVenue.setLocation(userLocation);
            newVenue.setType(VenueType.valueOf(locationType));

            EditText name = (EditText) findViewById(R.id.locationNameInput);
            newVenue.setName(name.getText().toString());

            RestHelper.getInstance().createVenue(this, newVenue);
        }
    }

    @Override
    public void onLocationChanged(Location location) {
            userLocation = location;
            Log.e("Location Changed", userLocation.toString());
    }

    public void createLocation(View view) {
        //create venue
        if (userLocation == null) {
            requestLocation();
        }
        handleLocation();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        locationType = parent.getSelectedItem().toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
