package com.timmcvicker.budgetminder;

public class RegisterException extends Exception {
    public RegisterException(String message) {
        super(message);
    }
}
