package com.timmcvicker.budgetminder;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.idescout.sql.SqlScoutServer;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public static void finishLogin(Context context) {
        UserManager userManager = UserManager.getInstance();

        String loginError = userManager.getLoginError();
        if (loginError == null) {
            //login successful
            Intent intentToLogin = new Intent(context, HomeActivity.class);
            Toast.makeText(context, "logging in user: " + userManager.getUsername(), Toast.LENGTH_SHORT).show();
            RestHelper.getInstance().getAllTransactionsForUser(context);
            RestHelper.getInstance().getAllVenues(context);
            context.startActivity(intentToLogin);

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setMessage("Login failed: " + userManager.getLoginError());
            builder.setPositiveButton("Try again", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        }

    }
    public void login(View view) {
        RestHelper restHelper = RestHelper.getInstance();

        EditText usernameField = (EditText) findViewById(R.id.usernameInput);
        EditText passwordField = (EditText) findViewById(R.id.passwordInput);

        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        restHelper.loginUser(username, password, this);
    }

    public void register(View view) {
        Intent intentToRegister = new Intent(this, ManageAccountActivity.class);
        startActivity(intentToRegister);
    }
}
