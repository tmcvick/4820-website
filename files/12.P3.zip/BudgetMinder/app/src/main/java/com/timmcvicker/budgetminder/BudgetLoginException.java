package com.timmcvicker.budgetminder;

public class BudgetLoginException extends Exception {
    public BudgetLoginException(String message) {
        super(message);
    }

    public BudgetLoginException() {
        super();
    }
}
