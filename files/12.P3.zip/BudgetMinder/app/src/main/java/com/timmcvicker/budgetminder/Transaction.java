package com.timmcvicker.budgetminder;

import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

import static android.content.ContentValues.TAG;

public class Transaction {
    private Integer id;
    private String description;
    private Double amount;
    private Date date;
    private boolean isRecurring;
    private Integer recurringInDays;
    private boolean isExpense;
    private Integer userId;
    private Integer locationId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setDate(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());

        try {
            this.date = dateFormat.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
            Log.d(TAG, "Error while trying to parse date");

        }    }

    public boolean isRecurring() {
        return isRecurring;
    }

    public void setRecurring(String recurring) {
        if (recurring.equals("1"))
            isRecurring = true;
        else
            isRecurring = false;
    }

    public Integer getRecurringInDays() {
        return recurringInDays;
    }

    public void setRecurringInDays(Integer recurringInDays) {
        this.recurringInDays = recurringInDays;
    }

    public boolean isExpense() {
        return isExpense;
    }

    public void setExpense(String expense) {
        if (expense.equals("1"))
            isExpense = true;
        else
            isExpense = false;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getLocationId() {
        return locationId;
    }

    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    /**
     * a comparator that will order ListItems by date ascending
     */
    public static Comparator<Transaction> TransactionDateComparator = new Comparator<Transaction>() {

        public int compare(Transaction item1, Transaction item2) {
            Date dueDate1 = item1.getDate();
            Date dueDate2 = item2.getDate();

            //ascending order
            //return dueDate1.compareTo(dueDate2);

            //descending order
            return dueDate2.compareTo(dueDate1);
        }};

    @Override
    //obj must be integer
    public boolean equals(Object obj) {
        if(!(obj instanceof Transaction)) return false;

        return getLocationId().equals(((Transaction) obj).getLocationId());
    }
}
