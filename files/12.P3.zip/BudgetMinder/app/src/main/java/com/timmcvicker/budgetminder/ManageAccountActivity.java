package com.timmcvicker.budgetminder;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class ManageAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_account);
    }

    public void register(View view) {
        EditText nameField = (EditText) findViewById(R.id.nameInput);
        EditText passwordField = (EditText) findViewById(R.id.passwordInput3);
        EditText passwordField2 = (EditText) findViewById(R.id.passwordInput2);
        EditText usernameField = (EditText) findViewById(R.id.usernameInput2);
        EditText balanceField = (EditText) findViewById(R.id.balanceInput);

        String name = nameField.getText().toString();
        String password = passwordField.getText().toString();
        String password2 = passwordField2.getText().toString();
        String username = usernameField.getText().toString();
        Double balance = Double.parseDouble(balanceField.getText().toString());

        if (!password.equals(password2)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Passwords did not match!");
            builder.setPositiveButton("Try again", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            if(BudgetDatabaseHelper.getInstance(this).doesUserExist(username, this)) {
                Toast.makeText(this, "Unable to create user: " + username + ". User already exists", Toast.LENGTH_LONG).show();

            } else {
                RestHelper.getInstance().createUser(name, username, password, balance, this);
            }
        }
    }

    public static void finishRegister(String username, Integer userId, Context context) {
        BudgetDatabaseHelper.getInstance(context).addUser(username, userId);
        if (RestHelper.getInstance().getCurrentException() == null) {
            //register was successful
            Toast.makeText(context, "User created: " + username, Toast.LENGTH_LONG).show();
            Intent intentBackToLogin = new Intent(context, LoginActivity.class);
            context.startActivity(intentBackToLogin);
        } else {
            Toast.makeText(context, "Unable to create user: " + username, Toast.LENGTH_LONG).show();

        }
    }
}
