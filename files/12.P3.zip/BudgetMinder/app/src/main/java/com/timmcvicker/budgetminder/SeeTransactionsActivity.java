package com.timmcvicker.budgetminder;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class SeeTransactionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_transactions);

        Map<Integer, Transaction> map = UserManager.getInstance().getUserTransactions();
        List<Transaction> transactionArrayList;
        if (map != null) {
            transactionArrayList = new ArrayList<>(map.values());
        } else {
            transactionArrayList = new ArrayList<>();
        }

        final Context context = this.getApplicationContext();
        if (transactionArrayList.isEmpty()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("You have entered no transactions");
            builder.setPositiveButton("Go back", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    startActivity(new Intent(context, HomeActivity.class));
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            Collections.sort(transactionArrayList, Transaction.TransactionDateComparator);
            TransactionAdapter adapter = new TransactionAdapter(this, transactionArrayList);

            // Attach the adapter to a ListView
            ListView listView = (ListView) findViewById(R.id.listView);
            listView.setAdapter(adapter);
        }
    }
}
