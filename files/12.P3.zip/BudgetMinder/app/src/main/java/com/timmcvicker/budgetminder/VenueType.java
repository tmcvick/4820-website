package com.timmcvicker.budgetminder;

public enum VenueType {
    GROCERY, GAS, WORK, FOOD, ENTERTAINMENT, HOME, FAMILY, CLOTHING, TOYS
}
