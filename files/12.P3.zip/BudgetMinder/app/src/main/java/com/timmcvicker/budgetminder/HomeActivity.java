package com.timmcvicker.budgetminder;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TextView balanceView = (TextView) findViewById(R.id.balance);
        DecimalFormat df = new DecimalFormat("$0.00");

        double balance = UserManager.getInstance().getUser_balance();
        balanceView.setText(String.valueOf(df.format(balance)));

        if(balance < 0)
            balanceView.setTextColor(Color.RED);
    }

    public void logout(View view) {
        UserManager.getInstance().clear();
        Intent intentToLogout = new Intent(this, LoginActivity.class);
        startActivity(intentToLogout);
    }

    public void updateProfile(View view) {
        startActivity(new Intent(this, UpdateProfileActivity.class));
    }

    public void seeTransactions(View view) {
        startActivity(new Intent(this, SeeTransactionsActivity.class));
    }

    public void newTransaction(View view) {
        startActivity(new Intent(this, EnterTransactionActivity.class));
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void seeStatistics(View view) {
        startActivity(new Intent(this, PersonalStatsActivity.class));
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void compareStats(View view) {
        startActivity(new Intent(this, CompareStatsActivity.class));
    }
}
