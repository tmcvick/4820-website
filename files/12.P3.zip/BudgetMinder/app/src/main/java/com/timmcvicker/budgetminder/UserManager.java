package com.timmcvicker.budgetminder;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class UserManager {

    private static UserManager sInstance;
    //gonna use these to store current user data
    private String username;
    private String user_name;
    private int user_id;
    private double user_balance;
    private String loginError;
    private Map<Integer, Transaction> userTransactions;
    private Map<Integer, Transaction> allTransactions;

    public static synchronized UserManager getInstance() {
        if (sInstance == null) {
            sInstance = new UserManager();
        }
        return sInstance;
    }

    private UserManager() {
        username = null;
        user_name = null;
        user_id = -1;
        user_balance = -1.0;
        loginError = null;
        userTransactions = null;
        allTransactions = null;
    }

    public void clear() {
        sInstance = new UserManager();
    }

    public Map<Integer, Transaction> getUserTransactions() {
        return userTransactions;
    }
    public Map<Integer, Transaction> getAllTransactions() {
        return allTransactions;
    }


    public void addTransaction(Transaction transaction) {
        if (transaction.getUserId() == user_id) {
            if (userTransactions == null) {
                userTransactions = new HashMap<>();
            }

            Integer key = transaction.getId();
            userTransactions.put(key, transaction);
        }

        if (allTransactions == null) {
            allTransactions = new HashMap<>();
        }

        Integer key = transaction.getId();
        allTransactions.put(key, transaction);
    }

    public Transaction getTransaction(Integer key) {
        if (!userTransactions.containsKey(key)) {
            return null;
        }

        return userTransactions.get(key);
    }

    public String getUsername() {
        return username;
    }

    public String getUser_name() {
        return user_name;
    }

    public int getUser_id() {
        return user_id;
    }

    public double getUser_balance() {
        return user_balance;
    }

    public String getLoginError() {
        return loginError;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public void setUser_balance(double user_balance) {
        this.user_balance = user_balance;
    }

    public void setLoginError(String loginError) {
        this.loginError = loginError;
    }

    public String toString() {
        return username + " " + user_name + " " + user_id + " " + user_balance;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public List<Venue> getTopThreeLocationsForUser() {
        List<Venue> venueList = new ArrayList<>();
        VenueManager venueManager = VenueManager.getInstance();

        List<Transaction> transactionList = new ArrayList<>(userTransactions.values());
        Map<Integer, Integer> countToKey = new TreeMap<>();

        for (Transaction transaction :
                transactionList) {
            int key = transaction.getLocationId();
            Transaction newTransaction = new Transaction();
            newTransaction.setLocationId(key);

            int count = Collections.frequency(transactionList, newTransaction);
            countToKey.put(key, count);
        }

        while(countToKey.size() > 0 && venueList.size() < 3) {
            Integer key1 = Collections.max(countToKey.entrySet(), Map.Entry.comparingByValue()).getKey();
            countToKey.remove(key1);
            venueList.add(venueManager.getById(key1));
        }

        return venueList;
    }

    public double getTotalSpentAtVenueByUser(Venue venue) {
        double total = 0.0;
        for (Transaction transaction :
                userTransactions.values()) {
            if (transaction.getLocationId().equals(venue.getId())) {
                if (transaction.isExpense())
                    total += transaction.getAmount();
                else
                    total -= transaction.getAmount();
            }
        }
        return total;
    }

    public double getTotalSpentByUser() {
        double total = 0.0;
        for (Transaction transaction :
                userTransactions.values()) {
                if (transaction.isExpense())
                    total += transaction.getAmount();
        }
        return total;
    }

    public double getTotalEarnedByUser() {
        double total = 0.0;
        for (Transaction transaction :
                userTransactions.values()) {
            if (!transaction.isExpense())
                total += transaction.getAmount();

        }
        return total;
    }

    public double getTotalSpentAtVenue(Venue venue) {
        double total = 0.0;
        for (Transaction transaction :
                allTransactions.values()) {
            if (transaction.getLocationId().equals(venue.getId())) {
                if (transaction.isExpense())
                    total += transaction.getAmount();
                else
                    total -= transaction.getAmount();
            }
        }
        return total;
    }

    public double getTotalSpent() {
        double total = 0.0;
        for (Transaction transaction :
                allTransactions.values()) {
            if (transaction.isExpense())
                total += transaction.getAmount();
        }
        return total;
    }

    public double getTotalEarned() {
        double total = 0.0;
        for (Transaction transaction :
                allTransactions.values()) {
            if (!transaction.isExpense())
                total += transaction.getAmount();

        }
        return total;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public List<Venue> getTopThreeLocations() {
        List<Venue> venueList = new ArrayList<>();
        VenueManager venueManager = VenueManager.getInstance();

        List<Transaction> transactionList = new ArrayList<>(allTransactions.values());
        Map<Integer, Integer> countToKey = new TreeMap<>();

        for (Transaction transaction :
                transactionList) {
            int key = transaction.getLocationId();
            Transaction newTransaction = new Transaction();
            newTransaction.setLocationId(key);

            int count = Collections.frequency(transactionList, newTransaction);
            countToKey.put(key, count);
        }

        while(countToKey.size() > 0 && venueList.size() < 3) {
            Integer key1 = Collections.max(countToKey.entrySet(), Map.Entry.comparingByValue()).getKey();
            countToKey.remove(key1);
            venueList.add(venueManager.getById(key1));
        }


        return venueList;
    }

}
