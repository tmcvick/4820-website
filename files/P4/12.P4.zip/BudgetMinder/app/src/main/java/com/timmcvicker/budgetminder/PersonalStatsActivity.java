package com.timmcvicker.budgetminder;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DecimalFormat;

/**
 * Activity that shows the personal statistics for one user
 * Shows top three locations, total earned, total spent
 */
public class PersonalStatsActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_stats);

        UserManager userManager = UserManager.getInstance();
        VenueAdapter adapter = new StatVenueAdapter(this, userManager.getTopThreeLocationsForUser(), true);
        ListView listView = (ListView) findViewById(R.id.listView3);
        listView.setAdapter(adapter);

        TextView tvTotalSpent = (TextView) findViewById(R.id.totalSpent);
        TextView tvTotalEarned = (TextView) findViewById(R.id.totalEarned);

        DecimalFormat df = new DecimalFormat("$0.00");
        tvTotalEarned.setText(String.valueOf(df.format(userManager.getTotalEarnedByUser())));
        tvTotalSpent.setText(String.valueOf(df.format(userManager.getTotalSpentByUser())));
        tvTotalSpent.setTextColor(Color.RED);
        tvTotalEarned.setTextColor(Color.GREEN);


    }
}
