package com.timmcvicker.budgetminder;

import android.location.Location;

import java.util.HashMap;
import java.util.Map;

/**
 * Manages all data for locations (venues) that have been entered by users
 */
public class VenueManager {
    private static VenueManager sInstance;

    private Map<Location, Venue> venueMap;

    /**
     *
     * @return singleton instance of the VenueManager
     */
    public static synchronized VenueManager getInstance() {
        if (sInstance == null) {
            sInstance = new VenueManager();
        }
        return sInstance;
    }

    private VenueManager() {
        venueMap = new HashMap<>();
    }

    /**
     * resets all data held by the VenueManager
     */
    public void clear() {
        sInstance = new VenueManager();
    }

    /**
     *
     * @return map of venues (AndroidLocation: Venue)
     */
    public Map<Location, Venue> getVenueMap() {
        return venueMap;
    }

    /**
     * Adds a location to the map of venues, keying off android:location
     *
     * @param venue venue to add
     */
    public void addVenue(Venue venue) {
        Location location = venue.getLocation();
        venueMap.put(location, venue);
    }

    /**
     *
     * @param location android:location to use as a key for finding a venue
     * @return venue at android:location if it exists in the map, null if otherwise
     */
    public Venue getVenueIfExists(Location location) {
        Location key = venueIsInMap(location);
        if (key != null) {
            return venueMap.get(key);
        }
        return null;
    }

    private Location venueIsInMap(Location location) {
        for (Location curr :
                venueMap.keySet()) {
            if (Math.abs(curr.getLongitude() - location.getLongitude()) < 0.0009 && Math.abs(curr.getLatitude() - location.getLatitude()) < 0.0009)
                return curr;
        }
        return null;
    }

    /**
     *
     * @param id venueId to find
     * @return venue with venueId if in map, null if otherwise
     */
    public Venue getById(Integer id) {
        for (Venue venue :
                venueMap.values()) {
            if (venue.getId() == id) return venue;
        }
        return null;
    }
}
