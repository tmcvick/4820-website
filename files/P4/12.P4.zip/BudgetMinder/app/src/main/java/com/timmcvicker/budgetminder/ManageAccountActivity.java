package com.timmcvicker.budgetminder;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Activity that represents the register screen
 */
public class ManageAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_account);
    }

    /**
     * attempts to register the used based on information in the input fields
     * validates new user with the internal database
     *
     * @param view register button
     */
    public void register(View view) {
        EditText nameField = (EditText) findViewById(R.id.nameInput);
        EditText passwordField = (EditText) findViewById(R.id.passwordInput3);
        EditText passwordField2 = (EditText) findViewById(R.id.passwordInput2);
        EditText usernameField = (EditText) findViewById(R.id.usernameInput2);
        EditText balanceField = (EditText) findViewById(R.id.balanceInput);

        String name = nameField.getText().toString();
        String password = passwordField.getText().toString();
        String password2 = passwordField2.getText().toString();
        String username = usernameField.getText().toString();
        Double balance = Double.parseDouble(balanceField.getText().toString());

        if (!password.equals(password2)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Passwords did not match!");
            builder.setPositiveButton("Try again", (dialog, which) -> dialog.dismiss());
            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            if (BudgetDatabaseHelper.getInstance(this).doesUserExist(username, this)) {
                Toast.makeText(this, "Unable to create user: " + username + ". User already exists", Toast.LENGTH_LONG).show();

            } else {
                RestHelper.getInstance().createUser(name, username, password, balance, this);
            }
        }
    }

    /**
     * Method that is called after the registration in the external db is complete. redirects to the login page or shows an error
     * adds a new user to the internal database
     *
     * @param username username that was created
     * @param userId   external primary key of the
     * @param context  application context
     */
    public static void finishRegister(String username, Integer userId, Context context) {
        BudgetDatabaseHelper.getInstance(context).addUser(username, userId);
        if (RestHelper.getInstance().getCurrentException() == null) {
            //register was successful
            Toast.makeText(context, "User created: " + username, Toast.LENGTH_LONG).show();
            Intent intentBackToLogin = new Intent(context, LoginActivity.class);
            context.startActivity(intentBackToLogin);
        } else {
            Toast.makeText(context, "Unable to create user: " + username, Toast.LENGTH_LONG).show();

        }
    }
}
