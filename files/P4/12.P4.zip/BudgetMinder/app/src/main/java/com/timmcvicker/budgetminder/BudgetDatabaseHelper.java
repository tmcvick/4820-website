package com.timmcvicker.budgetminder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

/**
 * Used to manage the internal database for the app
 *
 * @version 14
 */
public class BudgetDatabaseHelper extends SQLiteOpenHelper {

    // Database Info
    private static final String DATABASE_NAME = "budgetDatabase";
    private static final int DATABASE_VERSION = 14;

    // Table Names
    private static final String TABLE_TRANSACTION = "transactionTable";
    private static final String TABLE_USERS = "usersTable";
    private static final String TABLE_VENUES = "venuesTable";

    // transaction Table Columns
    private static final String KEY_ID = "id";
    private static final String KEY_DESC = "description";
    private static final String KEY_AMOUNT = "amount";
    private static final String KEY_DATE = "date";
    private static final String KEY_RECUR = "recurring_ind";
    private static final String KEY_DAYS = "days";
    private static final String KEY_EXPENSE = "expense";
    private static final String KEY_LOCATION = "location";
    private static final String KEY_USER = "user";

    private static final String KEY_USERNAME = "username";

    private static final String KEY_TYPE = "type";
    private static final String KEY_NAME = "name";
    private static final String KEY_LAT = "latitude";
    private static final String KEY_LONG = "longitude";

    private static BudgetDatabaseHelper sInstance;


    /**
     * @param context context that the database helper will be used in
     * @return the singleton instance of the database helper
     */
    public static synchronized BudgetDatabaseHelper getInstance(Context context) {
        // Use the application context, which will ensure that you
        // don't accidentally leak an Activity's context.
        // See this article for more information: http://bit.ly/6LRzfx
        if (sInstance == null) {
            sInstance = new BudgetDatabaseHelper(context.getApplicationContext());
        }
        return sInstance;
    }


    private BudgetDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Method that is called when database is configured. Overridden to allow for custom configs
     *
     * @param db instance of the SQLite database
     */
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
    }

    /**
     * Called when the database is created for the FIRST time, creates desired table.
     * If a database already exists on disk with the same DATABASE_NAME, this method will NOT be called.
     *
     * @param db instance of SQLite database for this app
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TRANSACTION_TABLE = "CREATE TABLE " + TABLE_TRANSACTION +
                "(" +
                KEY_ID + " INTEGER PRIMARY KEY NOT NULL," + // Define a primary key
                KEY_DESC + " TEXT NOT NULL," +
                KEY_AMOUNT + " REAL NOT NULL," +
                KEY_DATE + " DATETIME NOT NULL," +
                KEY_RECUR + " BOOLEAN NOT NULL DEFAULT FALSE," +
                KEY_DAYS + " INTEGER NOT NULL DEFAULT 0," +
                KEY_EXPENSE + " BOOLEAN NOT NULL," +
                KEY_LOCATION + " INTEGER," +
                KEY_USER + " INTEGER" +
                ")";

        String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USERS +
                "(" +
                KEY_ID + " INTEGER NOT NULL," + // Define a primary key
                KEY_USERNAME + " TEXT NOT NULL" +
                ")";

        String CREATE_VENUE_TABLE = "CREATE TABLE " + TABLE_VENUES +
                "(" +
                KEY_ID + " INTEGER NOT NULL," +
                KEY_NAME + " TEXT NOT NULL," +
                KEY_TYPE + " TEXT NOT NULL," +
                KEY_LAT + " REAL NOT NULL," +
                KEY_LONG + " REAL NOT NULL" +
                ")";

        db.execSQL(CREATE_TRANSACTION_TABLE);
        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_VENUE_TABLE);
    }

    /**
     * Called when the database needs to be upgraded.
     * This method will only be called if a database already exists on disk with the same DATABASE_NAME,
     * but the DATABASE_VERSION is different than the version of the database that exists on disk.
     *
     * @param db         instance of SQLite database
     * @param oldVersion old version of database
     * @param newVersion new version of database. hard coded as constant at top of class
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            // Simplest implementation is to drop all old tables and recreate them
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTION);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_VENUES);


            onCreate(db);
        }
    }

    private String getDateTime(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return dateFormat.format(date);
    }

    /**
     * Adds a user to the internal database to aid in username lookup
     *
     * @param username the username of the user to add to the database
     * @param userId   the primary key in the external database for the user
     */
    public void addUser(String username, Integer userId) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            values.put(KEY_USERNAME, username);
            values.put(KEY_ID, userId);

            long itemId = db.insertOrThrow(TABLE_USERS, null, values);
            db.setTransactionSuccessful();
        } catch (Exception e) {
            RestHelper.getInstance().setCurrentException(e);
            Log.e("Register", "Error while trying to add user to internal database");
            Log.e("Register", e.getMessage());
        } finally {
            db.endTransaction();
        }
    }

    /**
     * Checks whether the username exists in the internal database (to prevent duplicate registering)
     *
     * @param username desired register name
     * @param context  application context (for showing alert)
     * @return true if user exists, false otherwise
     */
    public boolean doesUserExist(String username, Context context) {
        syncUsers(context);
        String USER_FIND_QUERY =
                String.format("SELECT * FROM %s WHERE %s = '%s'",
                        TABLE_USERS, KEY_USERNAME, username);

        // "getReadableDatabase()" and "getWriteableDatabase()" return the same object (except under low
        // disk space scenarios)
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();

        Cursor cursor = db.rawQuery(USER_FIND_QUERY, null);
        if (cursor.moveToFirst()) {
            db.setTransactionSuccessful();

            cursor.close();
            db.endTransaction();
            return true;
        } else {
            db.setTransactionSuccessful();

            cursor.close();
            db.endTransaction();
            return false;
        }
    }

    private String getUsernameFromDB(Integer userId) {
        String USER_FIND_QUERY =
                String.format("SELECT username FROM %s WHERE %s = %d",
                        TABLE_USERS, KEY_ID, userId);

        // "getReadableDatabase()" and "getWriteableDatabase()" return the same object (except under low
        // disk space scenarios)
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();

        Cursor cursor = db.rawQuery(USER_FIND_QUERY, null);
        if (cursor.moveToFirst()) {
            String toReturn = cursor.getColumnName(0);
            db.setTransactionSuccessful();

            cursor.close();
            db.endTransaction();
            return toReturn;
        } else {
            db.setTransactionSuccessful();

            cursor.close();
            db.endTransaction();
            return "";
        }
    }

    /**
     * helper method to sync internal and external users
     *
     * @param context application context
     */
    public void syncUsers(Context context) {
        RestHelper.getInstance().getExternalUsers(context);
    }

    /**
     * Called at the end of the sync users method in RestHelper. Loads users from external db to internal
     *
     * @param externalUsers map of external users (userId maps to username)
     * @param context       application context
     */
    public static void finishSyncUsers(Map<Integer, String> externalUsers, Context context) {
        for (Integer key : externalUsers.keySet()) {
            if (!BudgetDatabaseHelper.getInstance(context).getUsernameFromDB(key).equals(externalUsers.get(key))) {
                BudgetDatabaseHelper.getInstance(context).updateUserOnId(key, externalUsers.get(key));
            }
        }
    }

    /**
     * Updates internal usernames
     *
     * @param oldUsername previous username
     * @param username    username to be updated
     */
    public void updateUser(String oldUsername, String username) {
        if (oldUsername.equals(username))
            return;

        SQLiteDatabase db = getWritableDatabase();
        int id = -1;
        String USER_FIND_QUERY = String.format("SELECT id FROM %s WHERE %s='%s'", TABLE_USERS, KEY_USERNAME, oldUsername);
        Cursor cursor = db.rawQuery(USER_FIND_QUERY, null);
        if (cursor.moveToFirst()) {
            id = cursor.getInt(0);
            db.beginTransaction();

            ContentValues values = new ContentValues();
            values.put(KEY_ID, id);
            values.put(KEY_USERNAME, username);
            int rows;
            rows = db.update(TABLE_USERS, values, KEY_ID + "=?", new String[]{String.valueOf(id)});

            cursor.close();
            if (rows > 0) {
                Log.i("User Update", "Updating local username for user " + username);
                db.setTransactionSuccessful();
            } else {
                Log.e("User Update", "Unable to update local username for user " + username);
            }
        } else {
            Log.e("User Update", "Unable to update local username for user " + username);
        }
        db.endTransaction();

    }

    private void updateUserOnId(Integer userId, String username) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();

        ContentValues values = new ContentValues();
        values.put(KEY_ID, userId);
        values.put(KEY_USERNAME, username);
        int rows;
        rows = db.update(TABLE_USERS, values, KEY_ID + "=?", new String[]{String.valueOf(userId)});

        if (rows > 0) {
            Log.i("User Update", "Updating local username for user " + username);
            db.setTransactionSuccessful();
        } else {
            addUser(username, userId);
        }
        db.endTransaction();

    }

    /**
     * Syncs internal and external transaction tables
     * This takes all transactions for a user and adds them into the internal database
     *
     * @param context application context
     */
    public static void syncTransactions(Context context) {
        Map<Integer, Transaction> externalTransactions = UserManager.getInstance().getUserTransactions();
        if (externalTransactions == null) return;
        for (Integer key : externalTransactions.keySet()) {
            BudgetDatabaseHelper.getInstance(context).addOrUpdateTransaction(externalTransactions.get(key));
        }
    }

    /**
     * Syncs internal and external location tables
     * This takes all locations in the VenueManager and adds them into the internal database
     *
     * @param context
     */
    public static void syncVenues(Context context) {
        Map<Location, Venue> externalVenues = VenueManager.getInstance().getVenueMap();
        if (externalVenues == null) return;
        for (Location key : externalVenues.keySet()) {
            BudgetDatabaseHelper.getInstance(context).addOrUpdateVenue(externalVenues.get(key));
        }
    }

    private void addOrUpdateVenue(Venue venue) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            values.put(KEY_NAME, venue.getName());
            values.put(KEY_TYPE, venue.getType().name());
            values.put(KEY_LAT, venue.getLocation().getLatitude());
            values.put(KEY_LONG, venue.getLocation().getLongitude());
            values.put(KEY_ID, venue.getId());


            // First try to update the item in case the item already exists in the database
            // This assumes descriptions are unique
            int rows = 0;
            if (venue.getId() > -1)
                rows = db.update(TABLE_VENUES, values, KEY_ID + "= ?", new String[]{String.valueOf(venue.getId())});

            // Check if update succeeded
            if (rows == 1) {
                db.setTransactionSuccessful();
            } else {
                // item with this description did not already exist, so insert new item
                db.insertOrThrow(TABLE_VENUES, null, values);
                db.setTransactionSuccessful();
            }
        } catch (Exception e) {
            Log.e("Sync Venue", "Error while trying to add or update venue " + e.getMessage());
        } finally {
            db.endTransaction();
        }

    }

    private void addOrUpdateTransaction(Transaction transaction) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            values.put(KEY_AMOUNT, transaction.getAmount());
            values.put(KEY_DESC, transaction.getDescription());
            values.put(KEY_DATE, getDateTime(transaction.getDate()));
            values.put(KEY_RECUR, transaction.isRecurring());
            values.put(KEY_DAYS, transaction.getRecurringInDays());
            values.put(KEY_EXPENSE, transaction.isExpense());
            values.put(KEY_LOCATION, transaction.getLocationId());
            values.put(KEY_USER, transaction.getUserId());


            // First try to update the item in case the item already exists in the database
            // This assumes descriptions are unique
            int rows = 0;
            if (transaction.getId() > -1)
                rows = db.update(TABLE_TRANSACTION, values, KEY_ID + "= ?", new String[]{String.valueOf(transaction.getId())});

            // Check if update succeeded
            if (rows == 1) {
                db.setTransactionSuccessful();
            } else {
                // item with this description did not already exist, so insert new item
                db.insertOrThrow(TABLE_TRANSACTION, null, values);
                db.setTransactionSuccessful();
            }
        } catch (Exception e) {
            Log.e("Sync Transaction", "Error while trying to add or update transaction " + e.getMessage());
        } finally {
            db.endTransaction();
        }

    }
}
