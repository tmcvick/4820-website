package com.timmcvicker.budgetminder;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Activity that lists all previously created locations (aka Venues)
 */
public class ListLocationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_location);

        Map<Location, Venue> map = VenueManager.getInstance().getVenueMap();
        final List<Venue> venueList;
        if (map != null) venueList = new ArrayList<>(map.values());
        else venueList = new ArrayList<>();

        if (venueList.isEmpty()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("There are no locations to choose from!");
            builder.setPositiveButton("Create New", (dialog, which) -> {
                dialog.dismiss();
                createNewLocation(null);
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            VenueAdapter adapter = new VenueAdapter(this, venueList);
            ListView listView = (ListView) findViewById(R.id.listView2);
            listView.setAdapter(adapter);

            listView.setOnItemClickListener((parent, view, position, id) -> {
                Venue venue = venueList.get(position);
                EnterTransactionActivity.finishCreate(venue, getApplicationContext());
            });
        }
    }

    /**
     * takes a user to the create location page
     *
     * @param view the create new button
     */
    public void createNewLocation(View view) {
        startActivity(new Intent(this, NewLocationActivity.class));
    }
}
