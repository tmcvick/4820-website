package com.timmcvicker.budgetminder;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DecimalFormat;

/**
 * Android activity which represents the screen that is presented after clicking "compare stats" in the home menu
 * Shows overall statistics from all users of the BudgetMinder app
 * Shows top three locations, total earned, total spent
 */
public class CompareStatsActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_stats);

        UserManager userManager = UserManager.getInstance();
        VenueAdapter adapter = new StatVenueAdapter(this, userManager.getTopThreeLocations(), false);
        ListView listView = (ListView) findViewById(R.id.listView3);
        listView.setAdapter(adapter);

        TextView tvTotalSpent = (TextView) findViewById(R.id.totalSpent);
        TextView tvTotalEarned = (TextView) findViewById(R.id.totalEarned);

        DecimalFormat df = new DecimalFormat("$0.00");
        tvTotalEarned.setText(String.valueOf(df.format(userManager.getTotalEarned())));
        tvTotalSpent.setText(String.valueOf(df.format(userManager.getTotalSpent())));
        tvTotalSpent.setTextColor(Color.RED);
        tvTotalEarned.setTextColor(Color.GREEN);


    }
}
