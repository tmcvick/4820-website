package com.timmcvicker.budgetminder;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Activity that represents the login screen
 */
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    /**
     * Called after the password/username are verified. populates all managers/sessions,
     * redirects to main menu or shows error as appropriate
     *
     * @param context application context
     * @see UserManager
     */
    public static void finishLogin(Context context) {
        UserManager userManager = UserManager.getInstance();

        String loginError = userManager.getLoginError();
        if (loginError == null) {
            //login successful
            Intent intentToLogin = new Intent(context, HomeActivity.class);
            Toast.makeText(context, "logging in user: " + userManager.getUsername(), Toast.LENGTH_SHORT).show();
            RestHelper.getInstance().getAllTransactionsForUser(context);
            RestHelper.getInstance().getAllVenues(context);
            context.startActivity(intentToLogin);

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setMessage("Login failed: " + userManager.getLoginError());
            builder.setPositiveButton("Try again", (dialog, which) -> dialog.dismiss());

            AlertDialog dialog = builder.create();
            dialog.show();
        }

    }

    /**
     * Called on click of login button. attempts to login user based on input fields
     *
     * @param view login button
     * @see RestHelper
     */
    public void login(View view) {
        RestHelper restHelper = RestHelper.getInstance();

        EditText usernameField = (EditText) findViewById(R.id.usernameInput);
        EditText passwordField = (EditText) findViewById(R.id.passwordInput);

        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        restHelper.loginUser(username, password, this);
    }

    /**
     * Redirects to the register activity
     *
     * @param view register button
     */
    public void register(View view) {
        Intent intentToRegister = new Intent(this, ManageAccountActivity.class);
        startActivity(intentToRegister);
    }
}
