package com.timmcvicker.budgetminder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Adapter used to display a venue (location) in the listLocation activity
 */
public class VenueAdapter extends ArrayAdapter<Venue> {
    /**
     * Creates a new adapter
     *
     * @param context application context
     * @param venueList list of venues to display
     */
    public VenueAdapter(Context context, List<Venue> venueList) {
        super(context, 0, venueList);
    }

    /**
     * Displays an individual venue
     *
     * @param position venue in the list to display
     * @param convertView
     * @param parent
     * @return view that contains the displayed venue
     */
    @Override
    @NonNull
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        Venue venue = getItem(position);

        if (convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.venue_layout, parent, false);

        TextView tvName = (TextView) convertView.findViewById(R.id.textViewLocationName);
        TextView tvType = (TextView) convertView.findViewById(R.id.textViewLocationType);

        tvName.setText(venue.getName());
        tvType.setText(venue.getType().name());

        return convertView;
    }
}
