package com.timmcvicker.budgetminder;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

/**
 * Adapter used to display transactions in a list
 * Displays the transaction title, date, amount, and location
 */
public class TransactionAdapter extends ArrayAdapter<Transaction> {
    /**
     * Creates a new adapter
     *
     * @param context              application context
     * @param transactionArrayList a list of transactions to display
     */
    public TransactionAdapter(Context context, List<Transaction> transactionArrayList) {
        super(context, 0, transactionArrayList);
    }

    /**
     * Displays an individual transaction
     *
     * @param position transaction in the list to display
     * @param convertView view that is changed to a transaction
     * @param parent view that the transaction is displayed in
     * @return view containing the transaction
     */
    @Override
    @NonNull
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        Transaction transaction = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.transaction_layout, parent, false);
        }

        // Lookup view for data population
        TextView tvTitle = (TextView) convertView.findViewById(R.id.tranDesc);
        TextView tvDate = (TextView) convertView.findViewById(R.id.dateView);
        TextView tvAmount = (TextView) convertView.findViewById(R.id.amountView);
        TextView tvLocation = (TextView) convertView.findViewById(R.id.locView);

        // Populate the data into the template view using the data object

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "MM/dd/yyyy", Locale.getDefault());

        tvDate.setText(dateFormat.format(transaction.getDate()));
        tvTitle.setText(transaction.getDescription());
        Double amount = transaction.getAmount();
        DecimalFormat df = new DecimalFormat("$0.00");
        if (transaction.isExpense()) {
            tvAmount.setText(String.valueOf(df.format(amount)));
            tvAmount.setTextColor(Color.RED);
        } else {
            tvAmount.setText(String.valueOf(df.format(amount)));
            tvAmount.setTextColor(Color.GREEN);
        }

        Venue venue = VenueManager.getInstance().getById(transaction.getLocationId());
        if (venue != null) {
            tvLocation.setText(venue.getName());
        } else {
            tvLocation.setText("");
        }

        // Return the completed view to render on screen
        return convertView;
    }
}
