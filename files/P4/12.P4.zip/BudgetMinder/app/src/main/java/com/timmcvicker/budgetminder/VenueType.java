package com.timmcvicker.budgetminder;

/**
 * Enum that represents the different types of venues (locations)
 */
public enum VenueType {
    GROCERY, GAS, WORK, FOOD, ENTERTAINMENT, HOME, FAMILY, CLOTHING, TOYS
}
