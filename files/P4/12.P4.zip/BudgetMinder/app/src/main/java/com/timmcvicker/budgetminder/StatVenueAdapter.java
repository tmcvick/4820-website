package com.timmcvicker.budgetminder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.List;

/**
 * Adapter that display Venues (aka locations) in the two statistics activities
 * Displays location name, type, and total amount spent (or earned, if spent < 0) at location
 */
public class StatVenueAdapter extends VenueAdapter {
    private boolean uflag;

    /**
     * @param context   application context
     * @param venueList list of venues to display
     * @param uflag     indicates whether this adapter is being used to display venues for a single user (true) or the overall total (false)
     */
    public StatVenueAdapter(Context context, List<Venue> venueList, boolean uflag) {
        super(context, venueList);
        this.uflag = uflag;
    }

    /**
     * Presents a view for a specific venue
     *
     * @param position    venue in list to display
     * @param convertView view that this will replace
     * @param parent      parent view that this will be displayed in
     * @return a view containing the desired venue
     */
    @Override
    @NonNull
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        Venue venue = getItem(position);
        Double total = 0.0;

        if (uflag)
            total = UserManager.getInstance().getTotalSpentAtVenueByUser(venue);
        else
            total = UserManager.getInstance().getTotalSpentAtVenue(venue);


        if (convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.stat_venue_layout, parent, false);

        TextView tvName = (TextView) convertView.findViewById(R.id.textViewLocationName);
        TextView tvType = (TextView) convertView.findViewById(R.id.textViewLocationType);
        TextView tvAmount = (TextView) convertView.findViewById(R.id.textViewLocationAmount);


        tvName.setText(venue.getName());
        tvType.setText(venue.getType().name());
        DecimalFormat df = new DecimalFormat("$0.00");
        if (total >= 0)
            tvAmount.setText("Total Spent: " + String.valueOf(df.format(total)));
        else
            tvAmount.setText("Total Earned: " + String.valueOf(df.format(Math.abs(total))));

        return convertView;
    }
}
