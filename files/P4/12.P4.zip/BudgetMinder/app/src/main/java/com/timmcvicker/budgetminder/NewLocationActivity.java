package com.timmcvicker.budgetminder;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.Arrays;
import java.util.List;

/**
 * Activity that represents the create new location screen.
 * This activity makes use of the Android Location Service
 */
public class NewLocationActivity extends AppCompatActivity implements LocationListener, AdapterView.OnItemSelectedListener {
    private LocationManager locationManager;
    private String locationType;
    private Location userLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_new);

        Spinner spinner = (Spinner) findViewById(R.id.spinner2);
        // Spinner Drop down elements
        List<VenueType> categories = Arrays.asList(VenueType.values());


        // Creating adapter for spinner
        ArrayAdapter<VenueType> dataAdapter = new ArrayAdapter<VenueType>(this, android.R.layout.simple_spinner_dropdown_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(this);

        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            //do same stuff
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
            } catch (SecurityException e) {
                e.printStackTrace();
            }

        }
    }

    /**
     * Method that is called when the activity asks for permission to access location services and the user clicks a response
     *
     * @param requestCode  code that corresponds to the request. set by developer in requestLocation()
     * @param permissions  permissions that the app currently has
     * @param grantResults permissions that have been granted by the user
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //do stuff
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                try {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
                } catch (SecurityException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    /**
     * This is called when there is no location update; ie the phone is at the last current known location
     * We want to set the userLocation to that last known location
     */
    private void requestLocation() {
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            //do same stuff
            try {
                userLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            } catch (SecurityException e) {
                e.printStackTrace();
            }

        }
        Log.e("Location Request", userLocation.toString());

    }

    /**
     * this ensures that the current location does not already exist as a venue, and then uses the RestHelper to either create
     * that venue or load the existing one
     *
     * @see RestHelper
     * @see VenueManager
     */
    private void handleLocation() {
        VenueManager venueManager = VenueManager.getInstance();
        Location newLocation = new Location("");
        newLocation.setLongitude(userLocation.getLongitude());
        newLocation.setLatitude(userLocation.getLatitude());
        final Venue venue = venueManager.getVenueIfExists(newLocation);
        final Context context = this.getApplicationContext();
        if (venue != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            String message = String.format("This location already exists! Name: %s, Type: %s", venue.getName(), venue.getType());
            builder.setMessage(message);
            builder.setPositiveButton("Use this location", (dialog, which) -> {
                dialog.dismiss();
                EnterTransactionActivity.finishCreate(venue, context);
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            Venue newVenue = new Venue();
            newVenue.setLocation(userLocation);
            newVenue.setType(VenueType.valueOf(locationType));

            EditText name = (EditText) findViewById(R.id.locationNameInput);
            newVenue.setName(name.getText().toString());

            RestHelper.getInstance().createVenue(this, newVenue);
        }
    }

    /**
     * Method that is fired when the user's location service indicates a change in location.
     * It sets the userLocation to the new location
     *
     * @param location the new location
     */
    @Override
    public void onLocationChanged(Location location) {
        userLocation = location;
        Log.e("Location Changed", userLocation.toString());
    }

    /**
     * Called when the user clicks to create a new venue.
     * If the location has not been changed, it then requests the last known location before continuing
     * Calls handleLocation()
     *
     * @param view create location button
     */
    public void createLocation(View view) {
        //create venue
        if (userLocation == null) {
            requestLocation();
        }
        handleLocation();
    }

    /**
     * Unused
     *
     * @param provider
     * @param status
     * @param extras
     */
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    /**
     * Unused
     *
     * @param provider
     */
    @Override
    public void onProviderEnabled(String provider) {

    }

    /**
     * Unused
     *
     * @param provider
     */
    @Override
    public void onProviderDisabled(String provider) {

    }

    /**
     * Called when a user selects the location type from the dropdown
     *
     * @param parent   adapter that shows the different options
     * @param view     the dropdown itself
     * @param position the position in the list of types
     * @param id       the id of the selected option
     */
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        locationType = parent.getSelectedItem().toString();
    }

    /**
     * Unused
     *
     * @param parent
     */
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
