package com.timmcvicker.budgetminder;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Activity that represents the update profile screen
 */
public class UpdateProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);
        UserManager userManager = UserManager.getInstance();
        EditText nameInput = (EditText) findViewById(R.id.updateNameInput);
        EditText usernameInput = (EditText) findViewById(R.id.updateUsernameInput);

        nameInput.setText(userManager.getUser_name());
        usernameInput.setText(userManager.getUsername());
    }

    /**
     * Attempts to update the user in the database based on user input fields
     * Validates the data being used based on internal database
     * Redirects to login screen
     *
     * @param view update user button
     */
    public void updateUser(View view) {
        EditText nameField = (EditText) findViewById(R.id.updateNameInput);
        EditText passwordField = (EditText) findViewById(R.id.updatePasswordInput);
        EditText passwordField2 = (EditText) findViewById(R.id.updatePasswordInput2);
        EditText usernameField = (EditText) findViewById(R.id.updateUsernameInput);

        String name = nameField.getText().toString();
        String password = passwordField.getText().toString();
        String password2 = passwordField2.getText().toString();
        String username = usernameField.getText().toString();
        int id = UserManager.getInstance().getUser_id();
        double balance = UserManager.getInstance().getUser_balance();
        String oldUsername = UserManager.getInstance().getUsername();

        if (!password.equals(password2)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Passwords did not match!");
            builder.setPositiveButton("Try again", (dialog, which) -> dialog.dismiss());
            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            if (!username.equals(oldUsername) && BudgetDatabaseHelper.getInstance(this).doesUserExist(username, this)) {
                Toast.makeText(this, "Unable to update user: " + username + ". User already exists", Toast.LENGTH_LONG).show();
            } else {
                RestHelper.getInstance().updateUser(id, name, username, password, balance);
                BudgetDatabaseHelper.getInstance(this).updateUser(oldUsername, username);
                if (RestHelper.getInstance().getCurrentException() == null) {
                    //register was successful
                    Toast.makeText(this, "User updated: " + username, Toast.LENGTH_LONG).show();
                    BudgetDatabaseHelper.getInstance(this).syncUsers(this);

                    Intent intentBackToLogin = new Intent(this, LoginActivity.class);
                    startActivity(intentBackToLogin);
                } else {
                    Toast.makeText(this, "Unable to update user: " + username, Toast.LENGTH_LONG).show();

                }
            }
        }
    }
}
