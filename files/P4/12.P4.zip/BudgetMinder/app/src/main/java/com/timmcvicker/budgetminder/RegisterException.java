package com.timmcvicker.budgetminder;

/**
 * Thrown when the app is unable to register a user
 */
public class RegisterException extends Exception {
    public RegisterException(String message) {
        super(message);
    }
}
