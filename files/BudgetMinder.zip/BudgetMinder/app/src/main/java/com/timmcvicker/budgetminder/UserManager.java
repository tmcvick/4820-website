package com.timmcvicker.budgetminder;

import android.content.Context;

import java.util.HashMap;
import java.util.Map;

public class UserManager {

    private static UserManager sInstance;
    //gonna use these to store current user data
    private String username;
    private String user_name;
    private int user_id;
    private double user_balance;
    private String loginError;
    private Map<Integer, Transaction> transactions;

    public static synchronized UserManager getInstance() {
        if (sInstance == null) {
            sInstance = new UserManager();
        }
        return sInstance;
    }

    private UserManager() {
        username = null;
        user_name = null;
        user_id = -1;
        user_balance = -1.0;
        loginError = null;
        transactions = null;
    }

    public void clear() {
        sInstance = new UserManager();
    }

    public Map<Integer, Transaction> getTransactions() {
        return transactions;
    }

    public void addTransaction(Transaction transaction) {
        if (transactions == null) {
            transactions = new HashMap<>();
        }

        Integer key = transaction.getId();
        transactions.put(key, transaction);
    }

    public Transaction getTransaction(Integer key) {
        if (!transactions.containsKey(key)) {
            return null;
        }

        return transactions.get(key);
    }

    public String getUsername() {
        return username;
    }

    public String getUser_name() {
        return user_name;
    }

    public int getUser_id() {
        return user_id;
    }

    public double getUser_balance() {
        return user_balance;
    }

    public String getLoginError() {
        return loginError;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public void setUser_balance(double user_balance) {
        this.user_balance = user_balance;
    }

    public void setLoginError(String loginError) {
        this.loginError = loginError;
    }

    public String toString() {
        return username + " " + user_name + " " + user_id + " " + user_balance;
    }
}
