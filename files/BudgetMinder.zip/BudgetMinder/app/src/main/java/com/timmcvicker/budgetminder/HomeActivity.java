package com.timmcvicker.budgetminder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TextView balanceView = (TextView) findViewById(R.id.balance);
        balanceView.setText(String.valueOf(UserManager.getInstance().getUser_balance()));
    }

    public void logout(View view) {
        UserManager.getInstance().clear();
        Intent intentToLogout = new Intent(this, LoginActivity.class);
        startActivity(intentToLogout);
    }

    public void updateProfile(View view) {
        startActivity(new Intent(this, UpdateProfileActivity.class));
    }

    public void seeTransactions(View view) {
        startActivity(new Intent(this, SeeTransactionsActivity.class));
    }

    public void newTransaction(View view) {
        startActivity(new Intent(this, EnterTransactionActivity.class));
    }
}
