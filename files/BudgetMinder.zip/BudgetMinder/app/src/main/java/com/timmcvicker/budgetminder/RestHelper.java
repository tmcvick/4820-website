package com.timmcvicker.budgetminder;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.SyncFailedException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class RestHelper {
    private static RestHelper sInstance;

    public Exception getCurrentException() {
        return currentException;
    }

    public void setCurrentException(Exception currentException) {
        this.currentException = currentException;
    }

    private Exception currentException;

    //used to return the id in create bc the api is stupid
    private Integer integerToReturn;

    public static synchronized RestHelper getInstance() {
        if (sInstance == null) {
            sInstance = new RestHelper();
        }
        return sInstance;
    }

    public RestHelper() {
        currentException = null;
    }

    //URLS
    private static final String URL_LOGIN = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/get_user.php";
    private static final String URL_CREATE_USER = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/create_user.php";
    private static final String URL_UPDATE_USER = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/update_user.php";
    private static final String URL_GET_TRANSACTIONS = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/get_transactions_for_user.php";
    private static final String URL_GET_USERS = "https://people.cs.clemson.edu/~tmcvick/cpsc4820/budget/get_all_users.php";

    public void loginUser(final String usernameInput, final String password, final Context activityContext) {
        currentException = null;
        new AsyncTask<Void,String,String>(){
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_LOGIN);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "uname=" + usernameInput;

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null)
                    {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    currentException = e;
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results){
                UserManager userManager = UserManager.getInstance();
                try {

                    if(!results.contains("No")){
                        JSONObject json = new JSONObject(results);

                        //this is successful, check pass
                        String passwordFromDB = json.getString("password");
                        if (passwordFromDB.equals(password)) {
                            //login successful
                            userManager.setUsername(json.getString("username"));
                            userManager.setUser_name(json.getString("name"));
                            userManager.setUser_id(json.getInt("id"));
                            userManager.setUser_balance(json.getDouble("balance"));
                            userManager.setLoginError(null);
                            Log.i("Login", "Logging in user: " + userManager.getUsername());
                        } else {
                            //login failed; incorrect password
                            userManager.setLoginError("Incorrect password");
                            Log.e("Login", "Incorrect password");
                        }
                    }
                    else{
                        //login failed-user doesn't exist
                        userManager.setLoginError("User does not exist");
                        Log.e("Login", "User " + usernameInput + " does not exist");
                    }
                } catch (JSONException e) {
                    //login failed-internal error
                    currentException = e;
                    userManager.setLoginError("Internal Error");
                    Log.e("Login", "Internal error " + e.getMessage());
                }
                LoginActivity.finishLogin(activityContext);
            }
        }.execute();
    }

    public void createUser(final String name, final String username, final String password, final Double balance, final Context activityContext) {
        currentException = null;
        integerToReturn = null;
        new AsyncTask<Void,String,String>(){
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_CREATE_USER);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "name=" + name + "&uname=" + username + "&balance=" + balance + "&pword=" + password;

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null)
                    {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results){
                try {
                    if(results.contains("user id created:")) {
                        Log.i("Register", "User " + username + " created.");

                        integerToReturn = Integer.parseInt(results.split(": ")[1].split("<")[0]);
                    }
                    else {
                        currentException = new RegisterException(username);
                        Log.e("Register", "Unable to create user " + username);
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("Register", "Internal error " + e.getMessage());
                }
                ManageAccountActivity.finishRegister(username, integerToReturn, activityContext);
            }
        }.execute();
    }

    public void updateUser(final int id, final String name, final String username, final String password, final Double balance) {
        currentException = null;
        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_UPDATE_USER);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "name=" + name + "&uname=" + username + "&balance=" + balance + "&pword=" + password + "&id=" + id;

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    if (results.contains("user id updated:")) {
                        Log.i("User Update", "User " + username + " updated.");
                        UserManager userManager = UserManager.getInstance();
                        userManager.setLoginError(null);
                        userManager.setUser_balance(balance);
                        userManager.setUser_id(id);
                        userManager.setUser_name(name);
                        userManager.setUsername(username);
                    } else {
                        currentException = new RegisterException(username);
                        Log.e("User Update", "Unable to update user " + username);
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("User Update", "Internal error " + e.getMessage());
                }
            }
        }.execute();
    }

    public void getExternalUsers(final Context context) {
        currentException = null;
        final Map<Integer, String> mapToReturn = new HashMap<>();
        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_GET_USERS);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "";

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    if (results.contains("No users found")) {
                        currentException = new SyncFailedException("Unable to sync users");
                        Log.e("User Sync", "Unable to sync users ");
                    } else {
                        JSONArray jsonArray = new JSONArray(results);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            mapToReturn.put(json.getInt("id"), json.getString("username"));
                        }
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("User Sync", "Internal error " + e.getMessage());
                }
                BudgetDatabaseHelper.finishSyncUsers(mapToReturn, context);
            }
        }.execute();
    }

    public void getAllTransactionsForUser(final Context context) {
        final UserManager userManager = UserManager.getInstance();
        final Integer userId = userManager.getUser_id();
        currentException = null;

        new AsyncTask<Void, String, String>() {
            @Override
            protected String doInBackground(Void... params) {
                try {
                    URL url = new URL(URL_GET_TRANSACTIONS);
                    HttpURLConnection client = (HttpURLConnection) url.openConnection();

                    client.setRequestMethod("POST");
                    client.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    client.setDoOutput(true);

                    String parameters = "id=" + userId;

                    OutputStreamWriter outputPost = new OutputStreamWriter(client.getOutputStream());
                    outputPost.write(parameters);
                    outputPost.flush();
                    outputPost.close();

                    String line = "";
                    InputStreamReader isr = new InputStreamReader(client.getInputStream());
                    BufferedReader reader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }

                    return sb.toString();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            protected void onPostExecute(String results) {
                try {
                    if (results.contains("No transactions")) {
                        Log.e("Get Transactions", "There are no transactions for " + userId);
                    } else {
                        JSONArray jsonArray = new JSONArray(results);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);

                            Transaction transaction = new Transaction();
                            transaction.setId(json.getInt("id"));
                            transaction.setDescription(json.getString("description"));
                            transaction.setAmount(json.getDouble("amount"));
                            transaction.setDate(json.getString("date"));
                            transaction.setRecurring(json.getString("recurring_ind"));
                            transaction.setRecurringInDays(json.getInt("recurring_in_days"));
                            transaction.setExpense(json.getString("expense_ind"));
                            transaction.setUserId(json.getInt("user_id"));
                            transaction.setLocationId(json.getInt("location_id"));

                            userManager.addTransaction(transaction);
                        }
                    }
                } catch (Exception e) {
                    currentException = e;
                    Log.e("Get Transactions", "Internal error " + e.getMessage());
                    e.printStackTrace();
                }
                BudgetDatabaseHelper.syncTransactions(context);
            }
        }.execute();
    }
}

