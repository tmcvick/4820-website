package com.timmcvicker.budgetminder;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends ArrayAdapter<Transaction> {
        public TransactionAdapter(Context context, List<Transaction> transactionArrayList) {
            super(context, 0, transactionArrayList);
        }

        @Override
        @NonNull
        public View getView(int position, View convertView, @NonNull ViewGroup parent) {
            Transaction transaction = getItem(position);

            // Check if an existing view is being reused, otherwise inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.transaction_layout, parent, false);
            }

            // Lookup view for data population
            TextView tvTitle = (TextView) convertView.findViewById(R.id.tranDesc);
            TextView tvDate = (TextView) convertView.findViewById(R.id.dateView);
            TextView tvAmount = (TextView) convertView.findViewById(R.id.amountView);

            Log.e("Date", String.valueOf(transaction.getDate()));
            // Populate the data into the template view using the data object

            SimpleDateFormat dateFormat = new SimpleDateFormat(
                "MM/dd/YYYY", Locale.getDefault());

            tvDate.setText(dateFormat.format(transaction.getDate()));
            tvTitle.setText(transaction.getDescription());
            Double amount = transaction.getAmount();
            if (transaction.isExpense()) {
                tvAmount.setText(String.valueOf(amount));
                tvAmount.setTextColor(Color.RED);
            } else {
                tvAmount.setText(String.valueOf(amount));
                tvAmount.setTextColor(Color.GREEN);
            }
            // Return the completed view to render on screen
            return convertView;
        }
}
